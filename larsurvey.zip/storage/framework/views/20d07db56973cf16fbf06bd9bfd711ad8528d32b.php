<?php $__env->startSection('content'); ?>

    <app></app>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.application', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>