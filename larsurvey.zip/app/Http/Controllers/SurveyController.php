<?php

namespace App\Http\Controllers;

use App\Models\Survey;
use Illuminate\Http\Request;
use Auth;

class SurveyController extends Controller
{
    /**
     * List of Surveys for Admin
     * @return Colletion | JSON
     */
    public function list(Request $request)
    {
    	return $request->user()->surveys;
    	return Survey::where('creator_id', $request->user()->id)->get;
    }

    /**
     * Store or Save New Survey
     * @return Survey | Object
     */
    public function store(Request $request)
    {
    	$request->merge(['creator_id' => $request->user()->id]);
    	Survey::create($request->all());
    	return  $request->user();
    }
    
}
