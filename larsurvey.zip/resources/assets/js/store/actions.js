export default {
	setUser(context) {
		console.log('Set User Action !!!!!!!!!!!!!!!!!!!!!!');
    	context.commit('SET_USER');
    }
}