export default {
  
  user: null,
  token: null,
  userInfo: {
    
  }
}