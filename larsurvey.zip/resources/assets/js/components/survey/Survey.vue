<template>
<div>
<h1>User's Surveys</h1>
<br>
  <el-row :gutter="10">
    <el-col :xs="24" :sm="12" :md="6" :lg="6" :xl="6" v-for="(survey,index) in surveys" :key="survey.id">
      <div class="grid-content bg-purple">
        <div class="title">
          {{survey.title}}
        </div>
        <div class="center" style="padding-bottom: 10px;">
          <span>Anonymous: <el-switch v-model="surveys[index].anonymous"></el-switch></span>
        </div>
        <div class="center" style="padding-bottom: 10px;">
          <span>Active: <el-switch v-model="surveys[index].active"></el-switch></span>
        </div>
        <div class="center">
          <el-button type="primary" icon="el-icon-plus" size="mini" @click="createQuestion(survey.id)">Add Question</el-button>
        </div>
      </div>
    </el-col>
    <!-- <el-col :xs="24" :sm="12" :md="6" :lg="6" :xl="6"><div class="grid-content bg-purple-light"></div></el-col>
    <el-col :xs="24" :sm="12" :md="6" :lg="6" :xl="6"><div class="grid-content bg-purple"></div></el-col>
    <el-col :xs="24" :sm="12" :md="6" :lg="6" :xl="6"><div class="grid-content bg-purple-light"></div></el-col> -->
  </el-row>
  <br>
  <!-- <v-client-table :data="tableData" :columns="columns" :options="options"></v-client-table> -->
</div>
</template>
<script>
  export default {
    mounted() {
      let Headerset = new Promise((resolve, reject) => {
          this.header = this.getHeaders(this.$store.state.user.access_token);
          if (this.header) {
              resolve(this.header);
          } else {
              reject('I will always love you');
          }
      });
      Headerset.then((comeback) => {
        console.log(`ComeBack!!!!!!!! ${comeback}`);
          this.getSurveys();
      }).catch((message) => {
          console.log(message); 
      });
      
    },
    data() {
      return {
        loading: false,
        header : {},
        surveys: [],
        form: {
          
        },
        columns: ['id', 'name', 'age'],
        tableData: [
            { id: 1, name: "John", age: "20" },
            { id: 2, name: "Jane", age: "24" },
            { id: 3, name: "Susan", age: "16" },
            { id: 4, name: "Chris", age: "55" },
            { id: 5, name: "Dan", age: "40" }
        ],
        options: {
            // see the options API
        }
      }
    },
    methods: {
      onSubmit() {
        console.log('submit!');
      },
      getSurveys(){
        let headers = this.header;
        axios.get('api/survey/list',{ headers }).then(response => {
          console.log(response);
          this.surveys = response.data;
        });
      },
      getHeaders(token) {
        return {
          Accept: 'application/json',
          Authorization: `Bearer ${token}`
        }
      },
      createQuestion(survey) {
        this.$router.push({ name: 'create-question', params: { survey }})
      }
    }
  }
</script>

<style>
  .title{
    text-align: center;
    font-size: 18px;
    font-weight: 700;
    padding-top: 5px;
    /*text-*/
  }
  .center{
    text-align: center;
  }
  .el-row {
    margin-bottom: 10px;
  }
  .el-col {
    border-radius: 4px;
  }
  .bg-purple-dark {
    background: #99a9bf;
  }
  .bg-purple {
    background: #d3dce6;
  }
  .bg-purple-light {
    background: #e5e9f2;
  }
  .grid-content {
    border-radius: 4px;
    min-height: 36px;
    margin-bottom: 36px;
  }
</style>